#pragma once

#include <libhydrix/hacpi/uacpi/helpers.h>

#define UACPI_ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))

#define UACPI_UNUSED(x) (void)(x)
