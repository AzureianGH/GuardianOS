#pragma once

#include <libhydrix/hacpi/uacpi/platform/compiler.h>
